package domain;

public class Manager {
	private String password;
	
	public Manager() {
		super();
	}

	public Manager(String password) {
		super();
		this.password = password;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
